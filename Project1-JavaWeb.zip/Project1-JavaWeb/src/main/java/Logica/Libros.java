/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

import java.util.ArrayList;

/**
 *
 * @author AcerPC
 */
public class Libros {
    
    String nombreLibros; 
    String generoLibro;
    String autorLibro;
    String PagLibro; 
   
    
    
    public Libros() {
    }

    public Libros(String nombreLibros, String generoLibro, String autorLibro, String PagLibro) {
        this.nombreLibros = nombreLibros;
        this.generoLibro = generoLibro;
        this.autorLibro = autorLibro;
        this.PagLibro = PagLibro;
       
    }

    public String getNombreLibros() {
        return nombreLibros;
    }

    public void setNombreLibros(String nombreLibros) {
        this.nombreLibros = nombreLibros;
    }

    public String getGeneroLibro() {
        return generoLibro;
    }

    public void setGeneroLibro(String generoLibro) {
        this.generoLibro = generoLibro;
    }

    public String getAutorLibro() {
        return autorLibro;
    }

    public void setAutorLibro(String autorLibro) {
        this.autorLibro = autorLibro;
    }

    public String getPagLibro() {
        return PagLibro;
    }

    public void setPagLibro(String PagLibro) {
        this.PagLibro = PagLibro;
    }

   
}
    

