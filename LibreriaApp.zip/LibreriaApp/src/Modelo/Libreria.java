/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author AcerPC
 */
public class Libreria {
    String tituloLibro;
    private ArrayList<Libro> listaLibros = new ArrayList<>();
 
    
    public Libreria (){
        listaLibros = new ArrayList<>();
        
    }
    
    public void addLibro(String titulo, String autor, String genero, int nPaginas, String publicacion) {
   
    Libro nuevoLibro = new Libro(titulo, autor, genero, nPaginas, publicacion);  
    listaLibros.add(nuevoLibro);
    
    System.out.println("Libro guardado: " + titulo);
}
    public boolean removeLibroPorTitulo(String titulo) {
    Iterator<Libro> iterator = listaLibros.iterator();
    while (iterator.hasNext()) {
        Libro libro = iterator.next();
        if (libro.getTitulo().equals(titulo)) {
            iterator.remove();
            return true; 
        }
    }
    return false; 
}
   public void addLibro(Libro nuevoLibro) {
    listaLibros.add(nuevoLibro);
    System.out.println("Libro guardado: " + nuevoLibro.getTitulo());
}

    public String getTituloLibro() {
        return tituloLibro;
    }

    public void setTituloLibro(String tituloLibro) {
        this.tituloLibro = tituloLibro;
    }

    public ArrayList<Libro> getListaLibros() {
        return listaLibros;
    }

    public void setListaLibros(ArrayList<Libro> listaLibros) {
        this.listaLibros = listaLibros;
    }
    
    public Libro buscarLibroPorTitulo(String titulo) {
        for (Libro libro : listaLibros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                return libro;
            }
        }
        return null; 
    }
    
}
