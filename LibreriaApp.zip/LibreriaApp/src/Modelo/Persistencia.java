/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author AcerPC
 */
public class Persistencia {
    
    public void guardar (Libreria x) throws FileNotFoundException, IOException{
        ObjectOutputStream ous = new ObjectOutputStream(new FileOutputStream ("Libreria.obj"));
        ous.writeObject(x);
        ous.close();
    }
    
    public Libreria recuperar () throws ClassNotFoundException, IOException{
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream ("Libreria.obj"));
        Libreria libreria = (Libreria) ois.readObject();
        ois.close();
        return libreria;
    }
    
}
